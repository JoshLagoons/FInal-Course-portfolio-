﻿using System;
using static System.Console;
using System.IO;


namespace Assignment2_FisherYatesShuffle
{
    class Program
    {
        static void Main()
        {
            string DataFile = "Brownpaperbag.txt";
            //gets the information from the text file
            var lines = File.ReadAllLines(DataFile);
            //reads it
            lines.MakeWordsShuffle();
            //gets the info from Theshuffle class and goes in the process of the algorithm
            File.WriteAllLines("Brownpaperbag.txt", lines);
              foreach (string phrase in lines)
                //loops it every time you boot it up again
                  Write(phrase + "\n ");
              ReadKey();

          
        }
    }
        
    
}
