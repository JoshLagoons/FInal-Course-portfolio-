﻿using System;
using static System.Console;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;

namespace Data_structures
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("This is a value storing an array");
            int i;
            int[] plus = new int[4];//giving me a 4 sized array
            
            //accepts the value from the user
            for(i = 0; i<4; i++)
            {
                Write("Enter a number:\t");
                //stores the value in a array
                plus[i] = Convert.ToInt32(ReadLine());
            }
            //prints the vallue on the console
            for(i = 0; i<4; i++)
            {
                Write("\nyou entered {0}", plus[i]);

            }
            ReadLine();
            //proceeds to do the rest of the classes
            maps();
            stack();
            queue();
           
        }
        static void maps()
        {

            WriteLine("\nThis is a value storing in maps");
            HashSet<int> oddNumbers = new HashSet<int>();
            HashSet<int> evenNumbers = new HashSet<int>();

            for (int j = 0; j < 8; j++)
            {
                oddNumbers.Add((j * 2) + 1);
                evenNumbers.Add(j * 2);

            }
            Write("The odd numbers have {0} elements: ", oddNumbers.Count);
            Build(oddNumbers);
            Write("The even numbers have {0} elements: ", evenNumbers.Count);
            Build(evenNumbers);

            HashSet<int> together = new HashSet<int>(oddNumbers);
            WriteLine("Now they will combine!!!");
            together.UnionWith(evenNumbers);
            Write("The numbers now have {0} elements: ", together.Count);
            Build(together);

            void Build(HashSet<int> storage)
            {
                Write("{");
                foreach (int w in storage)
                {
                    Write(" {0}", w);

                }
                WriteLine(" }");

            }

        }
        static void stack()
        {
            WriteLine("\nThis is a value storing in stack");
            //my stack class
            Stack spookytime = new Stack();
            //adding elements into the stack
            spookytime.Push("Wutang");
            spookytime.Push("GOLF");
            spookytime.Push("MFDOOM");
            spookytime.Push("I need to see..");
            spookytime.Push("777");
            spookytime.Push("10101");
            //to access this stack

            foreach(var uncutgems in spookytime)
            {
                WriteLine(uncutgems);

            }

        }
        static void queue()
        {
            WriteLine("\nThis is a value storing in stack");
            //queue class
            Queue butterdog = new Queue();
            //adds object into the queue 
            butterdog.Enqueue("Bobby hill");
            butterdog.Enqueue("chainsaws"); 
            butterdog.Enqueue("Denji"); 
            butterdog.Enqueue("POWER");
            butterdog.Enqueue("888");
            butterdog.Enqueue("Metropolis");
            //access the queue

            foreach(var goodtimes in butterdog)
            {
                WriteLine(goodtimes);
            }
            ReadKey();
        }
        
    }
}
